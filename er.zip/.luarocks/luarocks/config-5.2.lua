rocks_trees = {
   { name = [[system]], root = [[/home/testbd/Rex-Company/.luarocks]] }
}
